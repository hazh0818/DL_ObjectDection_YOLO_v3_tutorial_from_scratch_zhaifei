# Importing this adds THCUNN to type2backend dict in torch._thnn
# This automatically enables CUDA in all THNN ops
import torch._thnn.thcunn
