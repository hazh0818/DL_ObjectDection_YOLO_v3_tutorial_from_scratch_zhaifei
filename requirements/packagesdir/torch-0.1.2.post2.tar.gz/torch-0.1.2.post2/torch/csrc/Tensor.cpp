#include <Python.h>
#include <structmember.h>

#include <stdbool.h>
#include <vector>
#include <stack>
#include <tuple>
#include <TH/THMath.h>

#include "THP.h"

#include "generic/Tensor.cpp"
#include <TH/THGenerateAllTypes.h>

#include "generic/TensorCopy.cpp"
#include <TH/THGenerateAllTypes.h>
