#include <Python.h>
#include <structmember.h>

#include <stdbool.h>
#include <TH/TH.h>
#include <libshm.h>
#include "THP.h"

#include "generic/Storage.cpp"
#include <TH/THGenerateAllTypes.h>

#include "generic/StorageCopy.cpp"
#include <TH/THGenerateAllTypes.h>

