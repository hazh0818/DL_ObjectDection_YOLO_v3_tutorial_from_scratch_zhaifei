class Backends(object):
    pass
_backends = Backends()

type2backend = {}
